import Layout from "@/components/Layouts/Layout";
import withAuth from "@/components/withAuth";
import NumberFormat from "react-number-format";
import Moment from "react-moment";
import React from "react";
import { useAppDispatch } from "@/store/store";
import { courseSelector, getCourses, deleteCourse } from "@/store/slices/courseSlice";
import { useSelector } from "react-redux";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Close';
import {  GridRowsProp,GridRowModesModel,GridRowModes,DataGridPro,GridColDef,GridRowParams, MuiEvent, GridToolbarContainer, GridActionsCellItem, GridEventListener, GridRowId, GridRowModel,} from '@mui/x-data-grid-pro';
import { IconButton, Stack, Typography } from "@mui/material";
import { DataGrid, GridCellParams, GridRenderCellParams } from "@mui/x-data-grid";
import router from "next/router";
import { TransitionProps } from "@mui/material/transitions";
import Link from "next/link";
type Props = {};

export const columns: GridColDef<any, any, any>[] = [
  { field: "id", headerName: "ID", width: 100 },
  { field: "name", headerName: "Class ID", width: 130 },
  { field: "createdAt", headerName: "Created At", width: 200 },
  { field: "updatedAt", headerName: "Updated At", width: 200 },
];

const Instructor = ({}: Props) => {
  const dispatch = useAppDispatch();
  const courseList = useSelector(courseSelector);
  React.useEffect(() => {
    dispatch(getCourses(1));
  }, [dispatch]);
  React.useEffect(() => {
    setRows(courseList);
  }, [courseList]);

  const [rows, setRows] = React.useState(courseList);
  const [rowModesModel, setRowModesModel] = React.useState<GridRowModesModel>({});

  const columns: GridColDef[] = [
   
    { field: 'id_code', headerName: 'รหัสวิชา', width: 120  , editable: true},
    { field: 'name', headerName: 'ชื่อวิชา', width: 200 , editable: true },
    { headerName: "TIME", field: "เวลาสร้าง",width: 220,
      renderCell: ({ value }: GridRenderCellParams<string>) => (
        <Typography variant="body1">
          <Moment format="DD/MM/YYYY HH:mm">{value}</Moment>
        </Typography>
      ),
    }, {
      headerName: "ACTION",field: ".",  width: 120,
      renderCell: ({ row }: GridRenderCellParams<string>) => (
        <Stack direction="row">
          <IconButton
            aria-label="edit"
            size="large"
            onClick={() => router.push("/instructor/edit?id=" + row.id)}
          >
            <EditIcon fontSize="inherit" />
          </IconButton>
          <IconButton
            aria-label="delete"
            size="large"
            onClick={() => {
              setSelectedProduct(row);
              setOpenDialog(true);
            }}
          >
            <DeleteIcon fontSize="inherit" />
          </IconButton>
        </Stack>
      ),
    },
   
  ];
  
   
  return (
    <Layout>
      <Typography>รายการวิชา</Typography>
      <Box  sx={{    height: 600,    width: "100%", "& .super-app-theme--header": {backgroundColor: "#FF9800",color:"#FFF" } }}> 
        <DataGrid
          rows={rows ?? []}
          columns={columns} 
        />
      </Box>
      <Box>
      <Link href="/instructor/add" passHref>
        <Button>
          เพิ่มรายวิชา
        </Button>
        </Link>
      </Box>
    </Layout>
  );
};

export default withAuth(Instructor);