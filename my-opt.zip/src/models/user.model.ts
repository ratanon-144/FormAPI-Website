export interface UserData {
    id:       number;
    username: string;
    level:    string;
    email:    string;
    fullname: string;
    token?: string;
}
