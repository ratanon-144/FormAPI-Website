import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";

import * as serverService from "@/services/serverService";
import { CourseData } from "@/models/course.model";
import { RootState, store } from "../store";
import { NextRouter } from "next/router";

interface CourseState {
  courses: CourseData[];
}

const initialState: CourseState = {
  courses: [],
}; 

export const getCoses = createAsyncThunk(
  "course/get",
  async (id?: number) => {
    return await serverService.getCoses(id);
  }
);
export const addCourse = createAsyncThunk(
  "course/add",
  async (courseData: CourseData) => {
    return await serverService.addCourse(courseData);
  }
);

export const editCourse = createAsyncThunk(
  "course/edit",
  async (courseData: CourseData) => {
    return await serverService.editCourse(courseData);
  }
);

export const deleteCourse = createAsyncThunk(
  "course/delete",
  async (id: number) => {
    return await serverService.deleteCourse(id);
  }
);

const courseSlice = createSlice({
  name: "course",
  initialState: initialState,
  reducers: {
    setCourses: (state, action: PayloadAction<CourseData[]>) => {
      state.courses = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(getCoses.fulfilled, (state, action) => {
      state.courses = action.payload;
    });
    builder.addCase(addCourse.fulfilled, (state, action) => {
      state.courses.push(action.payload);
    });
    builder.addCase(editCourse.fulfilled, (state, action) => {
      const index = state.courses.findIndex((c) => c.id === action.payload.id);
      if (index !== -1) {
        state.courses[index] = action.payload;
      }
    });
    builder.addCase(deleteCourse.fulfilled, (state, action) => {
      state.courses = state.courses.filter((c) => c.id !== action.payload.id);
    });
  }
});

export const courseSelector = (store: RootState): CourseData[] | undefined =>
  store.course.courses;
export default courseSlice.reducer;
 