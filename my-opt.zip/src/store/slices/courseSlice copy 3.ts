import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import * as serverService from "@/services/serverService";
import { CourseData } from "@/models/course.model";
import { RootState } from "../store";

interface CourseState {
  courses: CourseData[];
  isLoading: boolean;
  error: string | null;
}

const initialState: CourseState = {
  courses: [],
  isLoading: false,
  error: null,
};

export const getCourses = createAsyncThunk(
  "courses/get",
  async (id?: number) => {
    return await serverService.getCourses(id);
  }
);

export const addCourse = createAsyncThunk(
  "courses/add",
  async (data: FormData) => {
    return await serverService.addCourse(data);
  }
);

export const editCourse = createAsyncThunk(
  "courses/edit",
  async (data: { id: number; formData: FormData }) => {
    return await serverService.editCourse(data.id, data.formData);
  }
);

export const deleteCourse = createAsyncThunk(
  "courses/delete",
  async (id: number) => {
    return await serverService.deleteCourse(id);
  }
);

const courseSlice = createSlice({
  name: "courses",
  initialState: initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getCourses.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getCourses.fulfilled, (state, action) => {
        state.courses = action.payload;
        state.isLoading = false;
      })
      .addCase(getCourses.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message ?? "Unknown error occurred";
      })
      .addCase(addCourse.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(addCourse.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(addCourse.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message ?? "Unknown error occurred";
      })
      .addCase(editCourse.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(editCourse.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(editCourse.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message ?? "Unknown error occurred";
      })
      .addCase(deleteCourse.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteCourse.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(deleteCourse.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message ?? "Unknown error occurred";
      });
  },
});

export const courseSelector = (store: RootState): CourseData[] | undefined =>
  store.course.courses;

export const isLoadingSelector = (store: RootState): boolean =>
  store.course.isLoading;

export const errorSelector = (store: RootState): string | null =>
  store.course.error;

export default courseSlice.reducer;
