import { SignUp, SignIn, GetSession } from "@/models/auth.model";
import { ProductData } from "@/models/product.model";
import { CourseData } from "@/models/course.model";
import { UserData } from "@/models/user.model";
import httpClient from "@/utils/httpClient";
import axios from "axios";

type signProps = {
  username: string;
  password: string;
};

export const signUp = async (user: signProps): Promise<SignUp> => {
  const response = await httpClient.post<SignUp>("/authen/register", user);
  return response.data;
};

export const signIn = async (user: signProps): Promise<SignIn> => {
  const { data: response } = await httpClient.post<SignIn>(
    `/auth/signin`,
    user,
    {
      baseURL: process.env.NEXT_PUBLIC_BASE_URL_LOCAL_API,
    }
  );
  return response;
};

export async function signOut() {
  const response = await httpClient.get(`/auth/signout`, {
    baseURL: process.env.NEXT_PUBLIC_BASE_URL_LOCAL_API,
  });
  return response.data;
}

export const getSession = async (): Promise<GetSession> => {
  const response = await httpClient.get(`/auth/session`, {
    baseURL: process.env.NEXT_PUBLIC_BASE_URL_LOCAL_API,
  });

  return response.data;
};

export const getProfiles = async (): Promise<UserData> => {
    // return (await httpClient.get(`/auth/profile`)).data;
    const response = await httpClient.get(`/auth/profile`, {
      baseURL: process.env.NEXT_PUBLIC_BASE_URL_LOCAL_API,
    }); 
    return response.data;
};

// export const getProducts = async (keyword?: string): Promise<ProductData[]> => {
//   if (keyword) {
//     return (await httpClient.get(`/stock/product/keyword/${keyword}`)).data;
//   } else {
//     return (await httpClient.get(`/stock/product`)).data;
//   }
// };

// export const doGetStockById = async (id: string) => {
//   const response = await httpClient.get(`/stock/product/${id}`);
//   return response.data;
// };

// export const addProduct = async (data: FormData): Promise<void> => {
//   await httpClient.post(`/stock/product`, data);
// };

// export const editProduct = async (data: FormData): Promise<void> => {
//   await httpClient.put(`/stock/product`, data);
// };

// export const deleteProduct = async (id?: string): Promise<void> => {
//   await httpClient.delete(`/stock/product/${id}`);
// };

// export const getCourses = async (id?: number): Promise<CourseData[]> => {
//   return (await httpClient.get(`/course/course/${id}`)).data;
// };
// export const addCourse = async (data: FormData):  Promise<void> => {
//    await httpClient.post(`/course/course/`,data);
// };
// export const editCourse = async (id: number , data?: FormData): Promise<void>  => {
//   try {
//     const response = await httpClient.put(`/course/${id}`, data);
//     if (response.status === 200) {
//       console.log('Course updated successfully');
//     } else {
//       console.error('Failed to update course');
//     }
//   } catch (error) {
//     console.error(error);
//   }
// };
// export const deleteCourse = async (id?: number): Promise<CourseData[]> => {
//   return (await httpClient.get(`/course/course/${id}`)).data;
// };

// export const helloTest = async (id?: number): Promise<CourseData[]> => {
//   return (await httpClient.get(`/course/course/${id}`)).data;
// };
export const getCourses = async (): Promise<CourseData[]> => {
  const response = await httpClient.get(`/course/courses`);
  return response.data;
};

export const addCourse = async (course: CourseData): Promise<void> => {
  await httpClient.post(`/course/courses`, course);
};

export const editCourse = async (course: CourseData): Promise<void> => {
  await httpClient.put(`/course/courses/${course.id}`, course);
};

export const deleteCourse = async (id: number): Promise<void> => {
  await httpClient.delete(`/course/courses/${id}`);
};